﻿using System;

public class Exam
{
	public Exam()
	{
	}
    public int StudentId { get; set; }
    public int ExamNumber { get; set; }
    public int Score { get; set; }

}
